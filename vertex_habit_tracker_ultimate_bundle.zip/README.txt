VERTEX HABIT TRACKER — ULTIMATE BUNDLE

Deploy all files together to the same GitHub Pages directory:
- index.html
- manifest.webmanifest
- sw.js
- icon.svg

PWA/offline: GitHub Pages HTTPS is required. Service worker caching only works after the first successful online load. Tailwind CSS and Google Fonts are external CDN resources; offline fallback may have reduced styling if they were not cached by the browser.

Data security: habits/goals/schedules/check-ins are stored in this browser's localStorage. Export a JSON backup regularly. Clearing browser data can erase records. Do not use private/shared devices for sensitive notes.

Cloud sync: intentionally NOT enabled. A real cloud sync requires a backend project, authenticated user accounts, database schema, authorization/RLS policies, and conflict handling. Do not put service-role secrets in client HTML. Configure a secure provider before claiming sync works.

Reminders: the browser-page reminder checker works while the page is open; mobile OS/browser may suspend it in background. This is not a guaranteed push-notification service.

Pomodoro: timer runs in-page and persists session count only; the active countdown is not preserved across reloads.
